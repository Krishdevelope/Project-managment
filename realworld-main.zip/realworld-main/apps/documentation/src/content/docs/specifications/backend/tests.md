---
title: Tests
---

Include _at least_ **one** unit test in your repo to demonstrate how testing works (full testing coverage is _not_ required!)
